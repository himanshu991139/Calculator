export const environment = {
  production: true,
  apiUrl: 'https://buyquantumseries-ab02c-default-rtdb.firebaseio.com/',
  apiKey: 'AIzaSyA0ccFE5xb0zKZTrTea8W5MBkDuDzW8vj4',
  firebaseConfig : {
    apiKey: "AIzaSyA0ccFE5xb0zKZTrTea8W5MBkDuDzW8vj4",
    authDomain: "buyquantumseries-ab02c.firebaseapp.com",
    databaseURL: "https://buyquantumseries-ab02c-default-rtdb.firebaseio.com",
    projectId: "buyquantumseries-ab02c",
    storageBucket: "buyquantumseries-ab02c.appspot.com",
    messagingSenderId: "146883791755",
    appId: "1:146883791755:web:cf917292fd8d2d09b07d8e",
    measurementId: "G-L16X7RMCGB"
  }
};
