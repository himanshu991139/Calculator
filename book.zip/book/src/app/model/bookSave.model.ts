export let bookState = {
    bookDetail:[]
}

// export let bookSave;
