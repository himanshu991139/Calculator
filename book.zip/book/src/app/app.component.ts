import { Component, OnInit } from '@angular/core';
import { bookState } from './model/bookSave.model';

import { AuthService } from './shared/services/auth.service';
import { BookService } from './shared/services/book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'book';
  constructor(private auth:AuthService,private book:BookService){}
  ngOnInit(){
    this.initializeBook();
    this.auth.autoSignIn();
    
  }
  initializeBook() {
    this.book.getBook().subscribe((res)=>{
      bookState.bookDetail=res
      console.log(bookState.bookDetail)
    })
  }
}
