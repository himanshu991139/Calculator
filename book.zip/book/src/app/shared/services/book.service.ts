import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { bookState } from 'src/app/model/bookSave.model';
@Injectable({
  providedIn: 'root',
})
export class BookService {
  constructor(private firestore: AngularFirestore) {}
  addBook(data) {
    return this.firestore.collection('books').add(data);
  }
  getBook() {
    return this.firestore.collection('books').valueChanges();
  }
  getBookDetails() {
    return bookState.bookDetail;
  }
}
