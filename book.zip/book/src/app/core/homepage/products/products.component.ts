import { Component, OnInit } from '@angular/core';
import { bookState } from 'src/app/model/bookSave.model';
import { BookService } from 'src/app/shared/services/book.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
})
export class ProductsComponent implements OnInit {
  bookDetail: any;
  bookDataStore: any;
  checkBoxValue = '';
  constructor(private book: BookService) {}

  ngOnInit(): void {
    this.bookInitialize();
  }
  
  bookInitialize() {
    if (this.book.getBookDetails().length > 0) {
      this.bookDetail = this.book.getBookDetails();
      this.bookDataStore = this.bookDetail;
    } else {
      setTimeout(() => {
        this.bookDetail = this.book.getBookDetails();
        this.bookDataStore = this.bookDetail;
      }, 3000);
    }
  }
  
  onlyOne(event: any) {
    var checkboxes = document.getElementsByName('check');
    this.checkBoxValue = event.target.id.trim();
    checkboxes.forEach((item: HTMLInputElement) => {
      if (item.id != event.target.id) {
        item.checked = false;
      }
    });
    this.filter();
  }
  filter(): void {
    this.bookDetail = this.bookDataStore;
    let branch: string = document
      .getElementById('branchMenu')
      .textContent.trim();

    let year: string = document
      .getElementById('yearDropdown')
      .textContent.trim();
    if (branch == 'Select Branch' && this.checkBoxValue != '') {
      branch = this.checkBoxValue;
    }
    if (branch != 'Select Branch' && year == 'Select Year') {
      this.branchFilter(branch);
    } else if (year != 'Select Year' && branch == 'Select Branch') {
      this.yearFilter(year);
    } else {
      this.branchFilter(branch);
      this.yearFilter(year);
    }
  }
  branchFilter(branch: string) {
    let filterResult = [];
    if (branch == 'All') {
      this.bookDetail = this.bookDataStore;
    } else {
      this.bookDetail.forEach((book) => {
        if (book.branch == branch) {
          filterResult.push(book);
        }
      });
      this.bookDetail = filterResult;
    }
  }
  yearFilter(year: string) {
    if (year == 'All') {
      return;
    }
    let filterResult = [];
    this.bookDetail.forEach((book) => {
      if (book.year == year) {
        filterResult.push(book);
      }
    });
    this.bookDetail = filterResult;
  }
  selectBranch(event) {
    let branch = event.target.innerText;
    let buttonText = document.getElementById('branchMenu');
    buttonText.innerHTML = branch;
    this.filter();
  }
  selectYear(event) {
    let year = event.target.innerText;
    let buttonText = document.getElementById('yearDropdown');
    buttonText.innerText = year;
    this.filter();
  }
}
