import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/services/auth.service';
import { BookService } from 'src/app/shared/services/book.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  isLoggedIn = false;
  searchFilter = [];
  constructor(private auth: AuthService, private book: BookService) {}

  ngOnInit(): void {
    this.auth.user.subscribe((res) => {
      this.isLoggedIn = !!res;
    });
  }
  signOut() {
    this.auth.signOut();
  }
  searchSubmit(data) {
    
  }
  searchOperation(searchText:string){
    let bookStore = this.book.getBookDetails();
    this.searchFilter = [];
    bookStore.forEach((book) => {
      if (
        book.bookName.toLowerCase().includes(searchText.toLowerCase()) ==
        true
      ) {
        console.log(book.bookName)
        this.searchFilter.push(book.bookName);
      }
    });
  }
}
