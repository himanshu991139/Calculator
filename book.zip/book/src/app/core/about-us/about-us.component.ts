import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService } from 'src/app/shared/services/book.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss'],
})
export class AboutUsComponent implements OnInit {
  bookForm: FormGroup;
  constructor(private fb: FormBuilder, private book: BookService) {}

  ngOnInit(): void {
    this.initalizeForm();
  }
  initalizeForm() {
    this.bookForm = this.fb.group({
      bookName: ['', [Validators.required]],
      authorName: ['', [Validators.required]],
      bookDescription: ['', [Validators.required]],
      tags: ['', [Validators.required]],
      imageUrl: ['', [Validators.required]],
      affilitateLink: ['', [Validators.required]],
      year: ['', [Validators.required]],
      branch: ['', [Validators.required]],
      language: ['', [Validators.required]],
    });
  }
  addBook(data) {
    this.book.addBook(data).then((res) => console.log(res));
  }
}
